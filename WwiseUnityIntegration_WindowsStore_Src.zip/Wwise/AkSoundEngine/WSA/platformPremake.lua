-- WSA Unity premake module
local platform = {}

function platform.setupTargetAndLibDir(baseTargetDir)
    targetdir(baseTargetDir .. "WSA/WSA_UWP_%{cfg.platform}/%{cfg.buildcfg}")
    libdirs(wwiseSDKEnv .. "/UWP_%{cfg.platform}" .. GetSuffixFromCurrentAction() .. "/%{cfg.buildcfg}/lib")
end

function platform.platformSpecificConfiguration()
end

return platform